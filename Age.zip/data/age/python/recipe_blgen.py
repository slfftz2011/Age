import json
import os
import re

def load_item_whitelist(file_path):
    """加载物品白名单，返回物品ID集合（忽略标签）"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    ids = set()
    for entry in data.get('values', []):
        if isinstance(entry, str) and not entry.startswith('#'):
            # 如果物品ID没有命名空间，补上 minecraft:
            if ':' not in entry:
                entry = f'minecraft:{entry}'
            ids.add(entry)
    return ids

def parse_recipe_file(file_path):
    """解析一个配方文件，返回配方ID（命名空间:路径）及其输出物品ID。若无输出则返回None"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        result = data.get('result')
        if not result:
            return None
        # result 可能是一个对象或字符串
        if isinstance(result, dict):
            item_id = result.get('id')
        else:
            item_id = result
        # 如果物品ID没有命名空间，补上 minecraft:
        if ':' not in item_id:
            item_id = f'minecraft:{item_id}'
        # 构建配方ID：从文件路径中提取命名空间和路径（去掉.json）
        rel_path = os.path.relpath(file_path, start=recipe_base)
        # 替换反斜杠（Windows）为斜杠，并去掉 .json
        rel_path = rel_path.replace('\\', '/')
        recipe_id = os.path.splitext(rel_path)[0]
        # 确保有命名空间（如果路径没有，补上 minecraft:）
        if '/' in recipe_id:
            parts = recipe_id.split('/', 1)
            ns = parts[0] if parts[0] else 'minecraft'
            path = parts[1] if len(parts) > 1 else ''
            recipe_id = f'{ns}:{path}'
        else:
            recipe_id = f'minecraft:{recipe_id}'
        return recipe_id, item_id
    except Exception as e:
        # 忽略无法解析的文件
        return None

def main():
    # 配置路径
    recipes_folder = './recipes'          # 原版 recipes 文件夹
    item_whitelist_file = 'old_stone_age.json'
    extra_recipes_file = 'extra_recipes.json'  # 手动补充配方（可选）
    output_file = 'allow_recipes.json'

    # 加载物品白名单
    allowed_items = load_item_whitelist(item_whitelist_file)
    print(f"物品白名单数量: {len(allowed_items)}")

    # 解析所有配方文件
    recipe_whitelist = set()
    if not os.path.isdir(recipes_folder):
        print(f"错误: 未找到配方目录 {recipes_folder}，请提供正确的路径。")
        return

    for root, dirs, files in os.walk(recipes_folder):
        for file in files:
            if not file.endswith('.json'):
                continue
            file_path = os.path.join(root, file)
            parsed = parse_recipe_file(file_path)
            if parsed is None:
                continue
            recipe_id, item_id = parsed
            if item_id in allowed_items:
                recipe_whitelist.add(recipe_id)

    print(f"通过配方解析得到的配方数量: {len(recipe_whitelist)}")

    # 加载额外手动添加的配方（例如自定义配方或特殊配方）
    if os.path.exists(extra_recipes_file):
        with open(extra_recipes_file, 'r', encoding='utf-8') as f:
            extra = json.load(f)
        for r in extra:
            recipe_whitelist.add(r)
        print(f"额外添加配方: {len(extra)} 个")

    # 输出排序后的白名单
    result = sorted(recipe_whitelist)
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"最终配方白名单已生成: {output_file}")
    print(f"共 {len(result)} 个配方。")

if __name__ == '__main__':
    main()