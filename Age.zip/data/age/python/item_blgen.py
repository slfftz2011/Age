import json
import os
import sys
from collections import defaultdict

# ---------- 硬编码的 1.21.10 所有物品 ID（来自注册表） ----------
# 如果你需要更完整的列表，可以从游戏数据生成，或从 https://minecraft.wiki 下载
ALL_ITEMS = [
    # ===== 基础物品 =====
    "minecraft:acacia_boat", "minecraft:acacia_chest_boat", "minecraft:acacia_door",
    "minecraft:acacia_fence", "minecraft:acacia_fence_gate", "minecraft:acacia_hanging_sign",
    "minecraft:acacia_leaves", "minecraft:acacia_log", "minecraft:acacia_planks",
    "minecraft:acacia_pressure_plate", "minecraft:acacia_sapling", "minecraft:acacia_sign",
    "minecraft:acacia_slab", "minecraft:acacia_stairs", "minecraft:acacia_trapdoor",
    "minecraft:acacia_wood", "minecraft:activator_rail", "minecraft:air",
    "minecraft:allay_spawn_egg", "minecraft:amethyst_block", "minecraft:amethyst_cluster",
    "minecraft:amethyst_shard", "minecraft:ancient_debris", "minecraft:andesite",
    "minecraft:andesite_slab", "minecraft:andesite_stairs", "minecraft:andesite_wall",
    "minecraft:angler_pottery_sherd", "minecraft:anvil", "minecraft:apple",
    "minecraft:archer_pottery_sherd", "minecraft:armor_stand", "minecraft:arms_up_pottery_sherd",
    "minecraft:arrow", "minecraft:axolotl_bucket", "minecraft:axolotl_spawn_egg",
    "minecraft:baked_potato", "minecraft:bamboo", "minecraft:bamboo_block",
    "minecraft:bamboo_button", "minecraft:bamboo_chest_raft", "minecraft:bamboo_door",
    "minecraft:bamboo_fence", "minecraft:bamboo_fence_gate", "minecraft:bamboo_hanging_sign",
    "minecraft:bamboo_mosaic", "minecraft:bamboo_mosaic_slab", "minecraft:bamboo_mosaic_stairs",
    "minecraft:bamboo_planks", "minecraft:bamboo_pressure_plate", "minecraft:bamboo_raft",
    "minecraft:bamboo_sign", "minecraft:bamboo_slab", "minecraft:bamboo_stairs",
    "minecraft:bamboo_trapdoor", "minecraft:barrel", "minecraft:barrier",
    "minecraft:basalt", "minecraft:bat_spawn_egg", "minecraft:beacon",
    "minecraft:bedrock", "minecraft:bee_nest", "minecraft:bee_spawn_egg",
    "minecraft:beef", "minecraft:beehive", "minecraft:beetroot",
    "minecraft:beetroot_seeds", "minecraft:beetroot_soup", "minecraft:bell",
    "minecraft:big_dripleaf", "minecraft:birch_boat", "minecraft:birch_chest_boat",
    "minecraft:birch_door", "minecraft:birch_fence", "minecraft:birch_fence_gate",
    "minecraft:birch_hanging_sign", "minecraft:birch_leaves", "minecraft:birch_log",
    "minecraft:birch_planks", "minecraft:birch_pressure_plate", "minecraft:birch_sapling",
    "minecraft:birch_sign", "minecraft:birch_slab", "minecraft:birch_stairs",
    "minecraft:birch_trapdoor", "minecraft:birch_wood", "minecraft:black_dye",
    "minecraft:blackstone", "minecraft:blackstone_slab", "minecraft:blackstone_stairs",
    "minecraft:blackstone_wall", "minecraft:blade_pottery_sherd", "minecraft:blast_furnace",
    "minecraft:blaze_powder", "minecraft:blaze_rod", "minecraft:blaze_spawn_egg",
    "minecraft:blue_dye", "minecraft:blue_ice", "minecraft:blue_orchid",
    "minecraft:bone", "minecraft:bone_block", "minecraft:bone_meal",
    "minecraft:book", "minecraft:bookshelf", "minecraft:bow",
    "minecraft:bowl", "minecraft:brain_coral", "minecraft:brain_coral_block",
    "minecraft:brain_coral_fan", "minecraft:bread", "minecraft:brewer_pottery_sherd",
    "minecraft:brewing_stand", "minecraft:brick", "minecraft:brick_slab",
    "minecraft:brick_stairs", "minecraft:brick_wall", "minecraft:bricks",
    "minecraft:brown_dye", "minecraft:brown_mushroom", "minecraft:brown_mushroom_block",
    "minecraft:bubble_coral", "minecraft:bubble_coral_block", "minecraft:bubble_coral_fan",
    "minecraft:bucket", "minecraft:budding_amethyst", "minecraft:bundle",
    "minecraft:cactus", "minecraft:cake", "minecraft:calcite",
    "minecraft:calibrated_sculk_sensor", "minecraft:camel_spawn_egg", "minecraft:campfire",
    "minecraft:candle", "minecraft:carrot", "minecraft:carrot_on_a_stick",
    "minecraft:cartography_table", "minecraft:carved_pumpkin", "minecraft:cat_spawn_egg",
    "minecraft:cauldron", "minecraft:cave_spider_spawn_egg", "minecraft:chain",
    "minecraft:chain_command_block", "minecraft:chainmail_boots", "minecraft:chainmail_chestplate",
    "minecraft:chainmail_helmet", "minecraft:chainmail_leggings", "minecraft:charcoal",
    "minecraft:cherry_boat", "minecraft:cherry_chest_boat", "minecraft:cherry_door",
    "minecraft:cherry_fence", "minecraft:cherry_fence_gate", "minecraft:cherry_hanging_sign",
    "minecraft:cherry_leaves", "minecraft:cherry_log", "minecraft:cherry_planks",
    "minecraft:cherry_pressure_plate", "minecraft:cherry_sapling", "minecraft:cherry_sign",
    "minecraft:cherry_slab", "minecraft:cherry_stairs", "minecraft:cherry_trapdoor",
    "minecraft:cherry_wood", "minecraft:chest", "minecraft:chest_minecart",
    "minecraft:chicken", "minecraft:chipped_anvil", "minecraft:chiseled_bookshelf",
    "minecraft:chiseled_deepslate", "minecraft:chiseled_nether_bricks", "minecraft:chiseled_polished_blackstone",
    "minecraft:chiseled_quartz_block", "minecraft:chiseled_red_sandstone", "minecraft:chiseled_sandstone",
    "minecraft:chiseled_stone_bricks", "minecraft:chorus_flower", "minecraft:chorus_fruit",
    "minecraft:chorus_plant", "minecraft:clay", "minecraft:clay_ball",
    "minecraft:clock", "minecraft:coal", "minecraft:coal_block",
    "minecraft:coal_ore", "minecraft:coarse_dirt", "minecraft:coast_armor_trim_smithing_template",
    "minecraft:cobbled_deepslate", "minecraft:cobbled_deepslate_slab", "minecraft:cobbled_deepslate_stairs",
    "minecraft:cobbled_deepslate_wall", "minecraft:cobblestone", "minecraft:cobblestone_slab",
    "minecraft:cobblestone_stairs", "minecraft:cobblestone_wall", "minecraft:cobweb",
    "minecraft:cocoa_beans", "minecraft:cod", "minecraft:cod_bucket",
    "minecraft:cod_spawn_egg", "minecraft:command_block", "minecraft:command_block_minecart",
    "minecraft:comparator", "minecraft:compass", "minecraft:composter",
    "minecraft:conduit", "minecraft:cooked_beef", "minecraft:cooked_chicken",
    "minecraft:cooked_cod", "minecraft:cooked_mutton", "minecraft:cooked_porkchop",
    "minecraft:cooked_rabbit", "minecraft:cooked_salmon",
    # ===== 铜制物品 (1.21.10 新增/变种) =====
    "minecraft:copper_block", "minecraft:copper_bulb", "minecraft:copper_door",
    "minecraft:copper_grate", "minecraft:copper_ingot", "minecraft:copper_ore",
    "minecraft:copper_trapdoor", "minecraft:cut_copper", "minecraft:cut_copper_slab",
    "minecraft:cut_copper_stairs", "minecraft:deepslate_copper_ore",
    "minecraft:exposed_copper", "minecraft:exposed_copper_bulb", "minecraft:exposed_copper_door",
    "minecraft:exposed_copper_grate", "minecraft:exposed_copper_trapdoor",
    "minecraft:exposed_cut_copper", "minecraft:exposed_cut_copper_slab", "minecraft:exposed_cut_copper_stairs",
    "minecraft:oxidized_copper", "minecraft:oxidized_copper_bulb", "minecraft:oxidized_copper_door",
    "minecraft:oxidized_copper_grate", "minecraft:oxidized_copper_trapdoor",
    "minecraft:oxidized_cut_copper", "minecraft:oxidized_cut_copper_slab", "minecraft:oxidized_cut_copper_stairs",
    "minecraft:raw_copper", "minecraft:raw_copper_block",
    "minecraft:weathered_copper", "minecraft:weathered_copper_bulb", "minecraft:weathered_copper_door",
    "minecraft:weathered_copper_grate", "minecraft:weathered_copper_trapdoor",
    "minecraft:weathered_cut_copper", "minecraft:weathered_cut_copper_slab", "minecraft:weathered_cut_copper_stairs",
    "minecraft:waxed_copper_block", "minecraft:waxed_copper_bulb", "minecraft:waxed_copper_door",
    "minecraft:waxed_copper_grate", "minecraft:waxed_copper_trapdoor",
    "minecraft:waxed_cut_copper", "minecraft:waxed_cut_copper_slab", "minecraft:waxed_cut_copper_stairs",
    "minecraft:waxed_exposed_copper", "minecraft:waxed_exposed_copper_bulb", "minecraft:waxed_exposed_copper_door",
    "minecraft:waxed_exposed_copper_grate", "minecraft:waxed_exposed_copper_trapdoor",
    "minecraft:waxed_exposed_cut_copper", "minecraft:waxed_exposed_cut_copper_slab", "minecraft:waxed_exposed_cut_copper_stairs",
    "minecraft:waxed_oxidized_copper", "minecraft:waxed_oxidized_copper_bulb", "minecraft:waxed_oxidized_copper_door",
    "minecraft:waxed_oxidized_copper_grate", "minecraft:waxed_oxidized_copper_trapdoor",
    "minecraft:waxed_oxidized_cut_copper", "minecraft:waxed_oxidized_cut_copper_slab", "minecraft:waxed_oxidized_cut_copper_stairs",
    "minecraft:waxed_weathered_copper", "minecraft:waxed_weathered_copper_bulb", "minecraft:waxed_weathered_copper_door",
    "minecraft:waxed_weathered_copper_grate", "minecraft:waxed_weathered_copper_trapdoor",
    "minecraft:waxed_weathered_cut_copper", "minecraft:waxed_weathered_cut_copper_slab", "minecraft:waxed_weathered_cut_copper_stairs",
    # ===== 其他 =====
    "minecraft:cornflower", "minecraft:cow_spawn_egg", "minecraft:cracked_deepslate_bricks",
    "minecraft:cracked_deepslate_tiles", "minecraft:cracked_nether_bricks", "minecraft:cracked_polished_blackstone_bricks",
    "minecraft:cracked_stone_bricks", "minecraft:crafting_table", "minecraft:creeper_banner_pattern",
    "minecraft:creeper_spawn_egg", "minecraft:crimson_button", "minecraft:crimson_door",
    "minecraft:crimson_fence", "minecraft:crimson_fence_gate", "minecraft:crimson_fungus",
    "minecraft:crimson_hanging_sign", "minecraft:crimson_hyphae", "minecraft:crimson_nylium",
    "minecraft:crimson_planks", "minecraft:crimson_pressure_plate", "minecraft:crimson_roots",
    "minecraft:crimson_sign", "minecraft:crimson_slab", "minecraft:crimson_stairs",
    "minecraft:crimson_stem", "minecraft:crimson_trapdoor", "minecraft:crossbow",
    "minecraft:crying_obsidian", "minecraft:cyan_dye",
    "minecraft:damaged_anvil", "minecraft:dandelion", "minecraft:dark_oak_boat",
    "minecraft:dark_oak_chest_boat", "minecraft:dark_oak_door", "minecraft:dark_oak_fence",
    "minecraft:dark_oak_fence_gate", "minecraft:dark_oak_hanging_sign", "minecraft:dark_oak_leaves",
    "minecraft:dark_oak_log", "minecraft:dark_oak_planks", "minecraft:dark_oak_pressure_plate",
    "minecraft:dark_oak_sapling", "minecraft:dark_oak_sign", "minecraft:dark_oak_slab",
    "minecraft:dark_oak_stairs", "minecraft:dark_oak_trapdoor", "minecraft:dark_oak_wood",
    "minecraft:dark_prismarine", "minecraft:dark_prismarine_slab", "minecraft:dark_prismarine_stairs",
    "minecraft:daylight_detector", "minecraft:dead_brain_coral", "minecraft:dead_brain_coral_block",
    "minecraft:dead_brain_coral_fan", "minecraft:dead_bubble_coral", "minecraft:dead_bubble_coral_block",
    "minecraft:dead_bubble_coral_fan", "minecraft:dead_bush", "minecraft:dead_fire_coral",
    "minecraft:dead_fire_coral_block", "minecraft:dead_fire_coral_fan", "minecraft:dead_horn_coral",
    "minecraft:dead_horn_coral_block", "minecraft:dead_horn_coral_fan", "minecraft:dead_tube_coral",
    "minecraft:dead_tube_coral_block", "minecraft:dead_tube_coral_fan", "minecraft:debug_stick",
    "minecraft:deepslate", "minecraft:deepslate_brick_slab", "minecraft:deepslate_brick_stairs",
    "minecraft:deepslate_brick_wall", "minecraft:deepslate_bricks", "minecraft:deepslate_coal_ore",
    "minecraft:deepslate_diamond_ore", "minecraft:deepslate_emerald_ore",
    "minecraft:deepslate_gold_ore", "minecraft:deepslate_iron_ore", "minecraft:deepslate_lapis_ore",
    "minecraft:deepslate_redstone_ore", "minecraft:deepslate_tile_slab", "minecraft:deepslate_tile_stairs",
    "minecraft:deepslate_tile_wall", "minecraft:deepslate_tiles", "minecraft:diamond",
    "minecraft:diamond_axe", "minecraft:diamond_block", "minecraft:diamond_boots",
    "minecraft:diamond_chestplate", "minecraft:diamond_helmet", "minecraft:diamond_hoe",
    "minecraft:diamond_horse_armor", "minecraft:diamond_leggings", "minecraft:diamond_ore",
    "minecraft:diamond_pickaxe", "minecraft:diamond_shovel", "minecraft:diamond_sword",
    "minecraft:diorite", "minecraft:diorite_slab", "minecraft:diorite_stairs",
    "minecraft:diorite_wall", "minecraft:dirt", "minecraft:dirt_path",
    "minecraft:disc_fragment_5", "minecraft:dispenser", "minecraft:dolphin_spawn_egg",
    "minecraft:donkey_spawn_egg", "minecraft:dragon_breath", "minecraft:dragon_head",
    "minecraft:dragon_spawn_egg", "minecraft:dried_kelp", "minecraft:dried_kelp_block",
    "minecraft:dripstone_block", "minecraft:dropper", "minecraft:drowned_spawn_egg",
    "minecraft:echo_shard", "minecraft:egg", "minecraft:elder_guardian_spawn_egg",
    "minecraft:elytra", "minecraft:emerald", "minecraft:emerald_block",
    "minecraft:emerald_ore", "minecraft:enchanted_book", "minecraft:enchanted_golden_apple",
    "minecraft:enchanting_table", "minecraft:ender_chest", "minecraft:ender_dragon_spawn_egg",
    "minecraft:ender_eye", "minecraft:ender_pearl", "minecraft:enderman_spawn_egg",
    "minecraft:endermite_spawn_egg", "minecraft:end_crystal", "minecraft:end_portal_frame",
    "minecraft:end_rod", "minecraft:end_stone", "minecraft:end_stone_brick_slab",
    "minecraft:end_stone_brick_stairs", "minecraft:end_stone_brick_wall", "minecraft:end_stone_bricks",
    "minecraft:evoker_spawn_egg", "minecraft:experience_bottle", "minecraft:eye_armor_trim_smithing_template",
    "minecraft:farmer_pottery_sherd", "minecraft:feather", "minecraft:fern",
    "minecraft:fire_charge", "minecraft:fire_coral", "minecraft:fire_coral_block",
    "minecraft:fire_coral_fan", "minecraft:firework_rocket", "minecraft:firework_star",
    "minecraft:fishing_rod", "minecraft:fletching_table", "minecraft:flint",
    "minecraft:flint_and_steel", "minecraft:flower_banner_pattern", "minecraft:flower_pot",
    "minecraft:fox_spawn_egg", "minecraft:frog_spawn_egg", "minecraft:furnace",
    "minecraft:furnace_minecart", "minecraft:ghast_spawn_egg", "minecraft:ghast_tear",
    "minecraft:gilded_blackstone", "minecraft:glistering_melon_slice", "minecraft:globe_banner_pattern",
    "minecraft:glow_berries", "minecraft:glow_ink_sac", "minecraft:glow_item_frame",
    "minecraft:glow_lichen", "minecraft:glow_squid_spawn_egg", "minecraft:glowstone",
    "minecraft:glowstone_dust", "minecraft:goat_horn", "minecraft:goat_spawn_egg",
    "minecraft:gold_block", "minecraft:gold_ingot", "minecraft:gold_nugget",
    "minecraft:gold_ore", "minecraft:golden_apple", "minecraft:golden_axe",
    "minecraft:golden_boots", "minecraft:golden_carrot", "minecraft:golden_chestplate",
    "minecraft:golden_helmet", "minecraft:golden_hoe", "minecraft:golden_horse_armor",
    "minecraft:golden_leggings", "minecraft:golden_pickaxe", "minecraft:golden_shovel",
    "minecraft:golden_sword", "minecraft:granite", "minecraft:granite_slab",
    "minecraft:granite_stairs", "minecraft:granite_wall", "minecraft:grass_block",
    "minecraft:gravel", "minecraft:gray_dye", "minecraft:green_dye",
    "minecraft:grindstone", "minecraft:guardian_spawn_egg", "minecraft:gunpowder",
    "minecraft:hanging_roots", "minecraft:hay_block", "minecraft:heart_of_the_sea",
    "minecraft:heart_pottery_sherd", "minecraft:hearty_pottery_sherd", "minecraft:heavy_weighted_pressure_plate",
    "minecraft:hoglin_spawn_egg", "minecraft:honey_block", "minecraft:honey_bottle",
    "minecraft:honeycomb", "minecraft:honeycomb_block", "minecraft:hopper",
    "minecraft:hopper_minecart", "minecraft:horn_coral", "minecraft:horn_coral_block",
    "minecraft:horn_coral_fan", "minecraft:horse_spawn_egg", "minecraft:host_armor_trim_smithing_template",
    "minecraft:husk_spawn_egg", "minecraft:ice", "minecraft:infested_chiseled_stone_bricks",
    "minecraft:infested_cobblestone", "minecraft:infested_cracked_stone_bricks", "minecraft:infested_deepslate",
    "minecraft:infested_mossy_stone_bricks", "minecraft:infested_stone", "minecraft:infested_stone_bricks",
    "minecraft:ink_sac", "minecraft:iron_axe", "minecraft:iron_bars",
    "minecraft:iron_block", "minecraft:iron_boots", "minecraft:iron_chestplate",
    "minecraft:iron_door", "minecraft:iron_golem_spawn_egg", "minecraft:iron_helmet",
    "minecraft:iron_hoe", "minecraft:iron_horse_armor", "minecraft:iron_ingot",
    "minecraft:iron_leggings", "minecraft:iron_nugget", "minecraft:iron_ore",
    "minecraft:iron_pickaxe", "minecraft:iron_shovel", "minecraft:iron_sword",
    "minecraft:iron_trapdoor", "minecraft:item_frame", "minecraft:jack_o_lantern",
    "minecraft:jigsaw", "minecraft:jukebox", "minecraft:jungle_boat",
    "minecraft:jungle_chest_boat", "minecraft:jungle_door", "minecraft:jungle_fence",
    "minecraft:jungle_fence_gate", "minecraft:jungle_hanging_sign", "minecraft:jungle_leaves",
    "minecraft:jungle_log", "minecraft:jungle_planks", "minecraft:jungle_pressure_plate",
    "minecraft:jungle_sapling", "minecraft:jungle_sign", "minecraft:jungle_slab",
    "minecraft:jungle_stairs", "minecraft:jungle_trapdoor", "minecraft:jungle_wood",
    "minecraft:kelp", "minecraft:knowledge_book", "minecraft:ladder",
    "minecraft:lantern", "minecraft:lapis_block", "minecraft:lapis_lazuli",
    "minecraft:lapis_ore", "minecraft:large_amethyst_bud", "minecraft:large_fern",
    "minecraft:lava_bucket", "minecraft:lead", "minecraft:leather",
    "minecraft:leather_boots", "minecraft:leather_chestplate", "minecraft:leather_helmet",
    "minecraft:leather_horse_armor", "minecraft:leather_leggings", "minecraft:lectern",
    "minecraft:lever", "minecraft:light", "minecraft:light_blue_dye",
    "minecraft:light_gray_dye", "minecraft:light_weighted_pressure_plate", "minecraft:lightning_rod",
    "minecraft:lily_of_the_valley", "minecraft:lily_pad", "minecraft:lime_dye",
    "minecraft:lingering_potion", "minecraft:lodestone", "minecraft:lodestone_compass",
    "minecraft:loom", "minecraft:magenta_dye", "minecraft:magma_block",
    "minecraft:magma_cream", "minecraft:magma_cube_spawn_egg", "minecraft:mangrove_boat",
    "minecraft:mangrove_chest_boat", "minecraft:mangrove_door", "minecraft:mangrove_fence",
    "minecraft:mangrove_fence_gate", "minecraft:mangrove_hanging_sign", "minecraft:mangrove_leaves",
    "minecraft:mangrove_log", "minecraft:mangrove_planks", "minecraft:mangrove_pressure_plate",
    "minecraft:mangrove_propagule", "minecraft:mangrove_roots", "minecraft:mangrove_sign",
    "minecraft:mangrove_slab", "minecraft:mangrove_stairs", "minecraft:mangrove_trapdoor",
    "minecraft:mangrove_wood", "minecraft:map", "minecraft:medium_amethyst_bud",
    "minecraft:melon", "minecraft:melon_seeds", "minecraft:melon_slice",
    "minecraft:milk_bucket", "minecraft:minecart", "minecraft:miner_pottery_sherd",
    "minecraft:mojang_banner_pattern", "minecraft:mooshroom_spawn_egg", "minecraft:moss_block",
    "minecraft:moss_carpet", "minecraft:mossy_cobblestone", "minecraft:mossy_cobblestone_slab",
    "minecraft:mossy_cobblestone_stairs", "minecraft:mossy_cobblestone_wall", "minecraft:mossy_stone_brick_slab",
    "minecraft:mossy_stone_brick_stairs", "minecraft:mossy_stone_brick_wall", "minecraft:mossy_stone_bricks",
    "minecraft:mourner_pottery_sherd", "minecraft:mud", "minecraft:mud_brick_slab",
    "minecraft:mud_brick_stairs", "minecraft:mud_brick_wall", "minecraft:mud_bricks",
    "minecraft:muddy_mangrove_roots", "minecraft:mule_spawn_egg", "minecraft:mushroom_stem",
    "minecraft:mushroom_stew", "minecraft:music_disc_11", "minecraft:music_disc_13",
    "minecraft:music_disc_5", "minecraft:music_disc_blocks", "minecraft:music_disc_cat",
    "minecraft:music_disc_chirp", "minecraft:music_disc_creator", "minecraft:music_disc_creator_music_box",
    "minecraft:music_disc_far", "minecraft:music_disc_mall", "minecraft:music_disc_mellohi",
    "minecraft:music_disc_otherside", "minecraft:music_disc_pigstep", "minecraft:music_disc_precipice",
    "minecraft:music_disc_relic", "minecraft:music_disc_stal", "minecraft:music_disc_strad",
    "minecraft:music_disc_wait", "minecraft:music_disc_ward", "minecraft:mutton",
    "minecraft:mycelium", "minecraft:name_tag", "minecraft:nautilus_shell",
    "minecraft:nether_brick", "minecraft:nether_brick_fence", "minecraft:nether_brick_slab",
    "minecraft:nether_brick_stairs", "minecraft:nether_brick_wall", "minecraft:nether_bricks",
    "minecraft:nether_gold_ore", "minecraft:nether_quartz_ore", "minecraft:nether_sprouts",
    "minecraft:nether_star", "minecraft:nether_wart", "minecraft:nether_wart_block",
    "minecraft:netherite_axe", "minecraft:netherite_block", "minecraft:netherite_boots",
    "minecraft:netherite_chestplate", "minecraft:netherite_helmet", "minecraft:netherite_hoe",
    "minecraft:netherite_ingot", "minecraft:netherite_leggings", "minecraft:netherite_pickaxe",
    "minecraft:netherite_scrap", "minecraft:netherite_shovel", "minecraft:netherite_sword",
    "minecraft:netherrack", "minecraft:note_block", "minecraft:oak_boat",
    "minecraft:oak_chest_boat", "minecraft:oak_door", "minecraft:oak_fence",
    "minecraft:oak_fence_gate", "minecraft:oak_hanging_sign", "minecraft:oak_leaves",
    "minecraft:oak_log", "minecraft:oak_planks", "minecraft:oak_pressure_plate",
    "minecraft:oak_sapling", "minecraft:oak_sign", "minecraft:oak_slab",
    "minecraft:oak_stairs", "minecraft:oak_trapdoor", "minecraft:oak_wood",
    "minecraft:observer", "minecraft:obsidian", "minecraft:ocelot_spawn_egg",
    "minecraft:ochre_froglight", "minecraft:orange_dye", "minecraft:orange_tulip",
    "minecraft:packed_ice", "minecraft:packed_mud", "minecraft:painting",
    "minecraft:pale_oak_boat", "minecraft:pale_oak_chest_boat", "minecraft:pale_oak_door",
    "minecraft:pale_oak_fence", "minecraft:pale_oak_fence_gate", "minecraft:pale_oak_hanging_sign",
    "minecraft:pale_oak_leaves", "minecraft:pale_oak_log", "minecraft:pale_oak_planks",
    "minecraft:pale_oak_pressure_plate", "minecraft:pale_oak_sapling", "minecraft:pale_oak_sign",
    "minecraft:pale_oak_slab", "minecraft:pale_oak_stairs", "minecraft:pale_oak_trapdoor",
    "minecraft:pale_oak_wood", "minecraft:paper", "minecraft:pearlescent_froglight",
    "minecraft:phantom_membrane", "minecraft:phantom_spawn_egg", "minecraft:pig_spawn_egg",
    "minecraft:piglin_banner_pattern", "minecraft:piglin_brute_spawn_egg", "minecraft:piglin_spawn_egg",
    "minecraft:pillager_spawn_egg", "minecraft:pink_dye", "minecraft:pink_tulip",
    "minecraft:piston", "minecraft:pitcher_plant", "minecraft:pitcher_pod",
    "minecraft:plenty_pottery_sherd", "minecraft:podzol", "minecraft:pointed_dripstone",
    "minecraft:poisonous_potato", "minecraft:polar_bear_spawn_egg", "minecraft:polished_andesite",
    "minecraft:polished_andesite_slab", "minecraft:polished_andesite_stairs", "minecraft:polished_basalt",
    "minecraft:polished_blackstone", "minecraft:polished_blackstone_brick_slab", "minecraft:polished_blackstone_brick_stairs",
    "minecraft:polished_blackstone_brick_wall", "minecraft:polished_blackstone_bricks", "minecraft:polished_blackstone_button",
    "minecraft:polished_blackstone_pressure_plate", "minecraft:polished_blackstone_slab", "minecraft:polished_blackstone_stairs",
    "minecraft:polished_blackstone_wall", "minecraft:polished_deepslate", "minecraft:polished_deepslate_slab",
    "minecraft:polished_deepslate_stairs", "minecraft:polished_deepslate_wall", "minecraft:polished_diorite",
    "minecraft:polished_diorite_slab", "minecraft:polished_diorite_stairs", "minecraft:polished_granite",
    "minecraft:polished_granite_slab", "minecraft:polished_granite_stairs", "minecraft:popped_chorus_fruit",
    "minecraft:porkchop", "minecraft:potato", "minecraft:potion",
    "minecraft:powder_snow_bucket", "minecraft:prismarine", "minecraft:prismarine_brick_slab",
    "minecraft:prismarine_brick_stairs", "minecraft:prismarine_bricks", "minecraft:prismarine_crystals",
    "minecraft:prismarine_shard", "minecraft:prismarine_slab", "minecraft:prismarine_stairs",
    "minecraft:prismarine_wall", "minecraft:prize_pottery_sherd", "minecraft:pufferfish",
    "minecraft:pufferfish_bucket", "minecraft:pufferfish_spawn_egg", "minecraft:pumpkin",
    "minecraft:pumpkin_pie", "minecraft:pumpkin_seeds", "minecraft:purple_dye",
    "minecraft:purpur_block", "minecraft:purpur_pillar", "minecraft:purpur_slab",
    "minecraft:purpur_stairs", "minecraft:quartz", "minecraft:quartz_block",
    "minecraft:quartz_bricks", "minecraft:quartz_pillar", "minecraft:quartz_slab",
    "minecraft:quartz_stairs", "minecraft:rabbit", "minecraft:rabbit_foot",
    "minecraft:rabbit_hide", "minecraft:rabbit_spawn_egg", "minecraft:rabbit_stew",
    "minecraft:rail", "minecraft:raiser_armor_trim_smithing_template", "minecraft:ravager_spawn_egg",
    "minecraft:raw_gold", "minecraft:raw_gold_block", "minecraft:raw_iron",
    "minecraft:raw_iron_block", "minecraft:recovery_compass", "minecraft:red_dye",
    "minecraft:red_mushroom", "minecraft:red_mushroom_block", "minecraft:red_nether_brick_slab",
    "minecraft:red_nether_brick_stairs", "minecraft:red_nether_brick_wall", "minecraft:red_nether_bricks",
    "minecraft:red_sand", "minecraft:red_sandstone", "minecraft:red_sandstone_slab",
    "minecraft:red_sandstone_stairs", "minecraft:red_sandstone_wall", "minecraft:red_tulip",
    "minecraft:redstone", "minecraft:redstone_block", "minecraft:redstone_lamp",
    "minecraft:redstone_ore", "minecraft:redstone_torch", "minecraft:repeater",
    "minecraft:repeating_command_block", "minecraft:respawn_anchor", "minecraft:rib_armor_trim_smithing_template",
    "minecraft:rooted_dirt", "minecraft:rose_bush", "minecraft:rotten_flesh",
    "minecraft:saddle", "minecraft:salmon", "minecraft:salmon_bucket",
    "minecraft:salmon_spawn_egg", "minecraft:sand", "minecraft:sandstone",
    "minecraft:sandstone_slab", "minecraft:sandstone_stairs", "minecraft:sandstone_wall",
    "minecraft:scaffolding", "minecraft:sculk", "minecraft:sculk_catalyst",
    "minecraft:sculk_sensor", "minecraft:sculk_shrieker", "minecraft:sculk_vein",
    "minecraft:sea_lantern", "minecraft:sea_pickle", "minecraft:seagrass",
    "minecraft:shaper_armor_trim_smithing_template", "minecraft:sheaf_pottery_sherd", "minecraft:shears",
    "minecraft:sheep_spawn_egg", "minecraft:shield", "minecraft:short_grass",
    "minecraft:shroomlight", "minecraft:shulker_box", "minecraft:shulker_spawn_egg",
    "minecraft:shulker_shell", "minecraft:silence_armor_trim_smithing_template", "minecraft:silverfish_spawn_egg",
    "minecraft:skeleton_horse_spawn_egg", "minecraft:skeleton_spawn_egg", "minecraft:skull_banner_pattern",
    "minecraft:slime_ball", "minecraft:slime_block", "minecraft:slime_spawn_egg",
    "minecraft:small_amethyst_bud", "minecraft:small_dripleaf", "minecraft:smithing_table",
    "minecraft:smoker", "minecraft:smooth_basalt", "minecraft:smooth_quartz",
    "minecraft:smooth_quartz_slab", "minecraft:smooth_quartz_stairs", "minecraft:smooth_red_sandstone",
    "minecraft:smooth_red_sandstone_slab", "minecraft:smooth_red_sandstone_stairs", "minecraft:smooth_sandstone",
    "minecraft:smooth_sandstone_slab", "minecraft:smooth_sandstone_stairs", "minecraft:smooth_stone",
    "minecraft:smooth_stone_slab", "minecraft:sniffer_egg", "minecraft:sniffer_spawn_egg",
    "minecraft:snort_pottery_sherd", "minecraft:snout_armor_trim_smithing_template", "minecraft:snow",
    "minecraft:snow_block", "minecraft:snow_golem_spawn_egg", "minecraft:snowball",
    "minecraft:soul_campfire", "minecraft:soul_lantern", "minecraft:soul_sand",
    "minecraft:soul_soil", "minecraft:soul_torch", "minecraft:spawner",
    "minecraft:spectral_arrow", "minecraft:spider_eye", "minecraft:spider_spawn_egg",
    "minecraft:spire_armor_trim_smithing_template", "minecraft:splash_potion", "minecraft:sponge",
    "minecraft:spore_blossom", "minecraft:spruce_boat", "minecraft:spruce_chest_boat",
    "minecraft:spruce_door", "minecraft:spruce_fence", "minecraft:spruce_fence_gate",
    "minecraft:spruce_hanging_sign", "minecraft:spruce_leaves", "minecraft:spruce_log",
    "minecraft:spruce_planks", "minecraft:spruce_pressure_plate", "minecraft:spruce_sapling",
    "minecraft:spruce_sign", "minecraft:spruce_slab", "minecraft:spruce_stairs",
    "minecraft:spruce_trapdoor", "minecraft:spruce_wood", "minecraft:spyglass",
    "minecraft:squid_spawn_egg", "minecraft:stick", "minecraft:sticky_piston",
    "minecraft:stone", "minecraft:stone_axe", "minecraft:stone_brick_slab",
    "minecraft:stone_brick_stairs", "minecraft:stone_brick_wall", "minecraft:stone_bricks",
    "minecraft:stone_button", "minecraft:stone_hoe", "minecraft:stone_pickaxe",
    "minecraft:stone_pressure_plate", "minecraft:stone_shovel", "minecraft:stone_slab",
    "minecraft:stone_stairs", "minecraft:stone_sword", "minecraft:stonecutter",
    "minecraft:stray_spawn_egg", "minecraft:strider_spawn_egg", "minecraft:string",
    "minecraft:stripped_acacia_log", "minecraft:stripped_acacia_wood", "minecraft:stripped_bamboo_block",
    "minecraft:stripped_birch_log", "minecraft:stripped_birch_wood", "minecraft:stripped_cherry_log",
    "minecraft:stripped_cherry_wood", "minecraft:stripped_crimson_hyphae", "minecraft:stripped_crimson_stem",
    "minecraft:stripped_dark_oak_log", "minecraft:stripped_dark_oak_wood", "minecraft:stripped_jungle_log",
    "minecraft:stripped_jungle_wood", "minecraft:stripped_mangrove_log", "minecraft:stripped_mangrove_wood",
    "minecraft:stripped_oak_log", "minecraft:stripped_oak_wood", "minecraft:stripped_pale_oak_log",
    "minecraft:stripped_pale_oak_wood", "minecraft:stripped_spruce_log", "minecraft:stripped_spruce_wood",
    "minecraft:stripped_warped_hyphae", "minecraft:stripped_warped_stem", "minecraft:structure_block",
    "minecraft:structure_void", "minecraft:sugar", "minecraft:sugar_cane",
    "minecraft:sunflower", "minecraft:suspicious_gravel", "minecraft:suspicious_sand",
    "minecraft:suspicious_stew", "minecraft:sweet_berries", "minecraft:swamp_pottery_sherd",
    "minecraft:tadpole_bucket", "minecraft:tadpole_spawn_egg", "minecraft:target",
    "minecraft:terracotta", "minecraft:tipped_arrow", "minecraft:tnt",
    "minecraft:tnt_minecart", "minecraft:torch", "minecraft:torchflower",
    "minecraft:torchflower_seeds", "minecraft:totem_of_undying", "minecraft:trader_llama_spawn_egg",
    "minecraft:trapped_chest", "minecraft:trident", "minecraft:tripwire_hook",
    "minecraft:tropical_fish", "minecraft:tropical_fish_bucket", "minecraft:tropical_fish_spawn_egg",
    "minecraft:tube_coral", "minecraft:tube_coral_block", "minecraft:tube_coral_fan",
    "minecraft:tuff", "minecraft:tuff_slab", "minecraft:tuff_stairs",
    "minecraft:tuff_wall", "minecraft:turtle_egg", "minecraft:turtle_helmet",
    "minecraft:turtle_spawn_egg", "minecraft:twisting_vines", "minecraft:vex_spawn_egg",
    "minecraft:villager_spawn_egg", "minecraft:vindicator_spawn_egg", "minecraft:vine",
    "minecraft:wandering_trader_spawn_egg", "minecraft:ward_armor_trim_smithing_template", "minecraft:warden_spawn_egg",
    "minecraft:warped_button", "minecraft:warped_door", "minecraft:warped_fence",
    "minecraft:warped_fence_gate", "minecraft:warped_fungus", "minecraft:warped_fungus_on_a_stick",
    "minecraft:warped_hanging_sign", "minecraft:warped_hyphae", "minecraft:warped_nylium",
    "minecraft:warped_planks", "minecraft:warped_pressure_plate", "minecraft:warped_roots",
    "minecraft:warped_sign", "minecraft:warped_slab", "minecraft:warped_stairs",
    "minecraft:warped_stem", "minecraft:warped_trapdoor", "minecraft:warped_wart_block",
    "minecraft:water_bucket", "minecraft:wheat", "minecraft:wheat_seeds",
    "minecraft:white_dye", "minecraft:white_tulip", "minecraft:wild_armor_trim_smithing_template",
    "minecraft:wind_charge", "minecraft:witch_spawn_egg", "minecraft:wither_rose",
    "minecraft:wither_skeleton_spawn_egg", "minecraft:wither_spawn_egg", "minecraft:wolf_spawn_egg",
    "minecraft:wooden_axe", "minecraft:wooden_hoe", "minecraft:wooden_pickaxe",
    "minecraft:wooden_shovel", "minecraft:wooden_sword", "minecraft:writable_book",
    "minecraft:written_book", "minecraft:yellow_dye", "minecraft:zoglin_spawn_egg",
    "minecraft:zombie_head", "minecraft:zombie_horse_spawn_egg", "minecraft:zombie_spawn_egg",
    "minecraft:zombie_villager_spawn_egg", "minecraft:zombified_piglin_spawn_egg",
    # ===== 1.21 新增陶片 =====
    "minecraft:danger_pottery_sherd",
    "minecraft:explorer_pottery_sherd",
    "minecraft:flow_pottery_sherd",
    "minecraft:friend_pottery_sherd",
    "minecraft:guster_pottery_sherd",
    "minecraft:heartbreak_pottery_sherd",
    "minecraft:howl_pottery_sherd",
    "minecraft:scrape_pottery_sherd",
    "minecraft:shelter_pottery_sherd",
    "minecraft:skull_pottery_sherd"
]

# ---------- 工具函数 ----------
def load_tag_definitions(tags_folder):
    """
    递归读取 tags_folder/items/ 下所有 JSON 文件，构建标签名到物品列表的映射。
    标签名格式：命名空间:路径，例如 "minecraft:logs"
    """
    tags_dir = os.path.join(tags_folder, "item")
    if not os.path.isdir(tags_dir):
        raise ValueError(f"找不到 item 目录: {tags_dir}")

    tag_map = {}  # tag_name -> list of item ids (可能包含其他标签，需要后续展开)
    for root, dirs, files in os.walk(tags_dir):
        for file in files:
            if not file.endswith(".json"):
                continue
            full_path = os.path.join(root, file)
            # 相对路径作为命名空间:路径
            rel_path = os.path.relpath(full_path, tags_dir)  # e.g. "minecraft/logs.json"
            # 转换为命名空间:路径（去掉 .json）
            rel_path_no_ext = os.path.splitext(rel_path)[0]
            # 用 os.path.sep 替换为 ':'
            tag_name = rel_path_no_ext.replace(os.path.sep, ":")
            try:
                with open(full_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                values = data.get("values", [])
                # 确保每个条目是字符串
                tag_map[tag_name] = [str(v) for v in values]
            except Exception as e:
                print(f"警告: 解析 {full_path} 失败: {e}", file=sys.stderr)
                continue
    return tag_map

def expand_tag(tag_name, tag_map, visited=None):
    """
    递归展开一个标签，返回包含的物品 ID 集合。
    """
    if visited is None:
        visited = set()
    if tag_name in visited:
        # 防止循环引用
        return set()
    visited.add(tag_name)
    if tag_name not in tag_map:
        # 如果是未知标签，视为空集合
        print(f"警告: 标签 {tag_name} 未定义", file=sys.stderr)
        return set()

    result = set()
    for entry in tag_map[tag_name]:
        if entry.startswith("#"):
            # 递归展开子标签
            sub_tag = entry[1:]  # 去掉 '#'
            result.update(expand_tag(sub_tag, tag_map, visited))
        else:
            # 普通物品 ID
            result.add(entry)
    return result

def main():
    if len(sys.argv) < 4:
        print("用法: python gen_blacklist_advanced.py <白名单文件> <标签文件夹> <输出黑名单文件>")
        print("示例: python gen_blacklist_advanced.py old_stone_age.json ./tags banned.json")
        sys.exit(1)

    whitelist_file = sys.argv[1]
    tags_folder = sys.argv[2]
    output_file = sys.argv[3]

    # 读取白名单
    try:
        with open(whitelist_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        whitelist_entries = data.get("values", [])
    except Exception as e:
        print(f"读取白名单失败: {e}", file=sys.stderr)
        sys.exit(1)

    # 加载标签定义
    try:
        tag_map = load_tag_definitions(tags_folder)
    except Exception as e:
        print(f"加载标签失败: {e}", file=sys.stderr)
        sys.exit(1)

    # 展开白名单中的所有标签，获得允许物品集合
    allowed = set()
    for entry in whitelist_entries:
        if not isinstance(entry, str):
            continue
        if entry.startswith("#"):
            tag = entry[1:]
            allowed.update(expand_tag(tag, tag_map))
        else:
            allowed.add(entry)

    # 从所有物品中减去允许的，得到黑名单
    banned = sorted(set(ALL_ITEMS) - allowed)

    # 输出黑名单
    output = {"values": banned}
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"生成黑名单成功: {output_file}")
    print(f"允许物品数: {len(allowed)}")
    print(f"黑名单物品数: {len(banned)}")

if __name__ == "__main__":
    main()