

# 从背包扣除 1 个特殊 flint
clear @s minecraft:flint[custom_data={special:1b,from:"old_stone_age"}] 1
# 给予 1 个打制石器（战利品表生成的物品）
loot give @s loot age:chipped_stone_tool