#-------------------------
# 时间更新
# age:updata/time
#-------------------------
scoreboard players remove a time 1200
execute if entity @a[team=old_stone_age] run scoreboard players add stage old_stone_age 1
execute if entity @a[team=mid_stone_age] run scoreboard players add stage mid_stone_age 1
execute if entity @a[team=new_stone_age] run scoreboard players add stage new_stone_age 1
execute if entity @a[team=copper_age] run scoreboard players add stage copper_age 1
execute if entity @a[team=bronze_age] run scoreboard players add stage bronze_age 1
execute if entity @a[team=pre_iron_age] run scoreboard players add stage pre_iron_age 1
execute if entity @a[team=mid_iron_age] run scoreboard players add stage mid_iron_age 1
execute if entity @a[team=late_iron_age] run scoreboard players add stage late_iron_age 1
execute if entity @a[team=steam_age] run scoreboard players add stage steam_age 1
execute if entity @a[team=steam_age_2] run scoreboard players add stage steam_age_2 1
execute if entity @a[team=steam_age_3] run scoreboard players add stage steam_age_3 1
execute if entity @a[team=steam_age_4] run scoreboard players add stage steam_age_4 1
execute if entity @a[team=steam_age_5] run scoreboard players add stage steam_age_5 1

effect give @a[team=old_stone_age] bad_omen 45 9
effect give @a[team=old_stone_age] raid_omen 45 9