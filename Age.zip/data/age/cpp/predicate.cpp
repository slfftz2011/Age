#include <iostream>
#include <fstream>
#include <vector>
#include <string>

// ---------- 极简 JSON 序列化----------
std::string escape_json(const std::string& s) {
    std::string out;
    for (char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out += c;
        }
    }
    return out;
}

// 生成单个槽位检测条件（字符串形式）
std::string make_slot_condition(const std::string& slot_id, const std::string& whitelist_tag) {
    // 构建如下 JSON 对象：
    // {
    //   "condition": "minecraft:entity_properties",
    //   "entity": "this",
    //   "predicate": {
    //     "minecraft:slots": {
    //       "<slot_id>": {
    //         "items": ["minecraft:air", "<whitelist_tag>"]
    //       }
    //     }
    //   }
    // }
    std::string json = R"({
        "condition": "minecraft:entity_properties",
        "entity": "this",
        "predicate": {
            "minecraft:slots": {
                ")" + slot_id + R"(": {
                    "items": ["minecraft:air", ")" + whitelist_tag + R"("]
                }
            }
        }
    })";
    return json;
}

// 生成所有槽位 ID 列表
std::vector<std::string> build_slot_ids() {
    std::vector<std::string> slots;
    // 背包 36 格（0-8 为快捷栏，9-35 为主背包）
    for (int i = 0; i < 36; ++i) {
        slots.push_back("container." + std::to_string(i));
    }
    // 副手
    slots.push_back("offhand");
    // 盔甲
    slots.push_back("armor.head");
    slots.push_back("armor.chest");
    slots.push_back("armor.legs");
    slots.push_back("armor.feet");
    // 合成栏（打开界面时）
    for (int i = 0; i < 4; ++i) {
        slots.push_back("player.crafting." + std::to_string(i));
    }
    // 鼠标拾取
    slots.push_back("player.cursor");
    return slots;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "用法: " << argv[0] << " <输出文件名.json>\n";
        std::cerr << "示例: " << argv[0] << " has_banned_items.json\n";
        return 1;
    }

    std::string output_file = argv[1];
    std::string whitelist_tag;  // 你的白名单标签
    cin >> whitelist_tag;
    
    auto slots = build_slot_ids();

    // 构建 all_of 的 terms 数组
    std::string terms_json = "[";
    for (size_t i = 0; i < slots.size(); ++i) {
        terms_json += make_slot_condition(slots[i], whitelist_tag);
        if (i + 1 < slots.size()) terms_json += ",";
    }
    terms_json += "]";

    // 构建最终谓词： inverted ( all_of ( terms ) )
    std::string final_json = R"({
    "condition": "inverted",
    "term": {
        "condition": "all_of",
        "terms": )" + terms_json + R"(
    }
})";

    // 写入文件
    std::ofstream file(output_file);
    if (!file) {
        std::cerr << "无法打开输出文件: " << output_file << "\n";
        return 1;
    }
    file << final_json;
    file.close();

    std::cout << "成功生成谓词文件: " << output_file << "\n";
    std::cout << "包含 " << slots.size() << " 个槽位的检测。\n";
    return 0;
}